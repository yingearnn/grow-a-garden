const currentUrl = window.location.protocol + "//" + window.location.host;

// ---------------- Auth Helpers ----------------
function getToken() {
    return localStorage.getItem('token');
}

function getUserId() {
    return localStorage.getItem('userId');
}

function checkAuth() {
    if (!getToken() || !getUserId()) {
        window.location.href = 'login.html';
    }
}

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('userId');
    localStorage.removeItem('username');
    window.location.href = 'login.html';
}

// ---------------- Load User Data ----------------
async function loadUserData() {
    const token = getToken();
    const userId = getUserId();

    try {
        const response = await fetch(`${currentUrl}/user/${userId}`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });

        if (response.status === 401) {
            alert('Session expired. Please login again.');
            logout();
            return;
        }

        if (!response.ok) throw new Error('Failed to fetch user data');

        const data = await response.json();
        const user = data[0];

        document.getElementById('username-display').textContent = user.username;
        document.getElementById('points-display').textContent = `Points: ${user.points}`;
        document.getElementById('networth-display').textContent = `Net Worth: $${user.net_worth}`;

        return user;
    } catch (error) {
        console.error('Error loading user data:', error);
        alert('Error loading user data');
    }
}

// ---------------- Load Garden Plots ----------------
async function loadGardenPlots() {
    const token = getToken();
    const userId = getUserId();
    const gardenPlotsDiv = document.getElementById('garden-plots');

    gardenPlotsDiv.innerHTML = '<div class="loading">Loading garden...</div>';

    try {
        const response = await fetch(`${currentUrl}/garden/${userId}/plots`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });

        if (response.status === 401) {
            alert('Session expired. Please login again.');
            logout();
            return;
        }

        if (!response.ok) throw new Error('Failed to fetch garden plots');

        const plots = await response.json();
        console.log('Garden plots:', plots);

        let plotsUsed = 0;
        let totalValue = 0;

        // Create 20 plots
        gardenPlotsDiv.innerHTML = '';
        for (let i = 1; i <= 20; i++) {
            const plot = plots.find(p => p.plot_number === i);
            const isEmpty = !plot || !plot.plant_id;

            if (!isEmpty) {
                plotsUsed++;
                totalValue += plot.value || 0;
            }

            const plotDiv = document.createElement('div');
            plotDiv.className = `garden-plot ${isEmpty ? 'empty' : 'planted'}`;
            plotDiv.dataset.plotNumber = i;

            if (isEmpty) {
                plotDiv.innerHTML = `
                    <div class="plot-content">
                        <p class="plot-number">#${i}</p>
                        <p class="plot-status">Empty</p>
                    </div>
                `;
            } else {
                plotDiv.innerHTML = `
                    <div class="plot-content">
                        <p class="plot-number">#${i}</p>
                        <p class="plant-name">${plot.name || 'Unknown'}</p>
                        <p class="plant-value">$${plot.value || 0}</p>
                        <button class="btn-harvest" data-plot-id="${plot.plot_id}">Harvest</button>
                    </div>
                `;
            }

            gardenPlotsDiv.appendChild(plotDiv);
        }

        // Update stats
        document.getElementById('plots-used').textContent = plotsUsed;
        document.getElementById('garden-value').textContent = totalValue;

        // Add harvest button handlers
        document.querySelectorAll('.btn-harvest').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                e.stopPropagation();
                const plotId = e.target.dataset.plotId;
                await harvestPlant(plotId);
            });
        });

    } catch (error) {
        console.error('Error loading garden plots:', error);
        gardenPlotsDiv.innerHTML = '<p>Error loading garden</p>';
    }
}

// ---------------- Harvest Plant ----------------
async function harvestPlant(plotId) {
    const token = getToken();
    const userId = getUserId();

    try {
        const response = await fetch(`${currentUrl}/garden/${userId}/harvest/${plotId}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.status === 401) {
            alert('Session expired. Please login again.');
            logout();
            return;
        }

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.message || 'Failed to harvest plant');
        }

        const result = await response.json();
        alert(`Harvested! Earned $${result.value} (added to net worth) and ${result.points} points!`);
        
        // Reload user data and garden
        await loadUserData();
        await loadGardenPlots();

    } catch (error) {
        console.error('Error harvesting plant:', error);
        alert('Error harvesting plant: ' + error.message);
    }
}

// ---------------- Harvest All Plants ----------------
async function harvestAllPlants() {
    const token = getToken();
    const userId = getUserId();

    try {
        const response = await fetch(`${currentUrl}/garden/${userId}/harvest-all`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.status === 401) {
            alert('Session expired. Please login again.');
            logout();
            return;
        }

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.message || 'Failed to harvest plants');
        }

        const result = await response.json();
        if (result.harvested === 0) {
            alert('No plants to harvest!');
        } else {
            alert(`Harvested ${result.harvested} plants! Earned $${result.total_value} (added to net worth) and ${result.total_points} points!`);
        }
        
        // Reload user data and garden
        await loadUserData();
        await loadGardenPlots();

    } catch (error) {
        console.error('Error harvesting all plants:', error);
        alert('Error harvesting all plants: ' + error.message);
    }
}

// ---------------- DOMContentLoaded ----------------
document.addEventListener('DOMContentLoaded', async () => {
    checkAuth();

    // Load user data and garden
    await loadUserData();
    await loadGardenPlots();

    // Add event listeners
    document.getElementById('logout-btn').addEventListener('click', logout);
    
    const harvestAllBtn = document.getElementById('harvest-all-btn');
    if (harvestAllBtn) {
        harvestAllBtn.addEventListener('click', harvestAllPlants);
    }
});