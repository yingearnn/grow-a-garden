const currentUrl = window.location.protocol + "//" + window.location.host;

// ---------------- Auth Helpers ----------------
function getToken() {
    return localStorage.getItem('token');
}

function getUserId() {
    return localStorage.getItem('userId');
}

function checkAuth() {
    if (!getToken() || !getUserId()) {
        window.location.href = 'login.html';
    }
}

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('userId');
    localStorage.removeItem('username');
    window.location.href = 'login.html';
}

// ---------------- Error Handling ----------------
function handleFetchError(error, fallbackMessage = 'An error occurred') {
    console.error(error);
    alert(fallbackMessage);
}

function handleUnauthorized() {
    alert('Session expired. Please login again.');
    logout();
}

// ---------------- Load User Data ----------------
async function loadUserData() {
    const token = getToken();
    const userId = getUserId();

    try {
        const response = await fetch(`${currentUrl}/user/${userId}`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });

        if (response.status === 401) {
            handleUnauthorized();
            return;
        }

        if (!response.ok) throw new Error('Failed to fetch user data');

        const data = await response.json();
        const user = data[0];

        document.getElementById('points-display').textContent = `Points: ${user.points}`;
        document.getElementById('networth-display').textContent = `Net Worth: $${user.net_worth}`;

        return user;
    } catch (error) {
        handleFetchError(error, 'Error loading user data');
    }
}

// ---------------- Load Plants ----------------
async function loadPlants() {
    const token = getToken();
    const plantsGrid = document.getElementById('plants-grid');

    // Show loading
    plantsGrid.innerHTML = '<div class="loading">Loading plants...</div>';

    try {
        const response = await fetch(`${currentUrl}/plants`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });

        if (!response.ok) throw new Error(`Failed to fetch plants: ${response.status}`);

        const plants = await response.json();
        console.log('Plants fetched:', plants);

        if (!plants || plants.length === 0) {
            plantsGrid.innerHTML = '<p>No plants available</p>';
            return;
        }

        // Pick 3 random plants to feature (with stock > 0 if possible)
        const availablePlants = plants.filter(p => p.stock > 0);
        const featuredPlants = [];
        
        // Try to get 3 plants with stock first
        const copy = availablePlants.length >= 3 ? [...availablePlants] : [...plants];
        
        for (let i = 0; i < 3 && copy.length > 0; i++) {
            const idx = Math.floor(Math.random() * copy.length);
            featuredPlants.push(copy[idx]);
            copy.splice(idx, 1);
        }

        plantsGrid.innerHTML = featuredPlants.map(plant => {
            const outOfStock = plant.stock <= 0;
            return `
                <div class="shop-item ${outOfStock ? 'out-of-stock' : ''}">
                    <h3>${plant.name}</h3>
                    <span class="rarity ${plant.rarity}">${plant.rarity.toUpperCase()}</span>
                    <p>Base Value: $${plant.value}</p>
                    <p class="price">Cost: ${plant.points} points</p>
                    <p>Stock: ${plant.stock}/${plant.max_stock}</p>
                    <button class="btn-buy" 
                        data-plant-id="${plant.plant_id}" 
                        data-cost="${plant.points}" 
                        ${outOfStock ? 'disabled' : ''}>
                        ${outOfStock ? 'Out of Stock' : 'Buy Plant'}
                    </button>
                </div>
            `;
        }).join('');

        // Add click handlers only to active buttons
        document.querySelectorAll('.btn-buy:not([disabled])').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const plantId = e.target.dataset.plantId;
                const cost = parseInt(e.target.dataset.cost);
                await buyPlant(plantId, cost);
            });
        });

    } catch (error) {
        console.error('Error in loadPlants:', error);
        plantsGrid.innerHTML = '<p>Error loading plants</p>';
    }
}


// ---------------- Load Tools ----------------
async function loadTools() {
    const token = getToken();
    const toolsGrid = document.getElementById('tools-grid');

    // Clear previous content and show loading
    toolsGrid.innerHTML = '<div class="loading">Loading tools...</div>';

    try {
        const response = await fetch(`${currentUrl}/tools`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });

        if (!response.ok) throw new Error('Failed to fetch tools');

        const tools = await response.json();

        if (!tools || tools.length === 0) {
            toolsGrid.innerHTML = '<p>No tools available</p>';
            return;
        }

        // Pick 1 random fertilizer to feature (with stock > 0 if possible)
        const availableTools = tools.filter(t => t.stock > 0);
        const toolToFeature = availableTools.length > 0 
            ? availableTools[Math.floor(Math.random() * availableTools.length)]
            : tools[Math.floor(Math.random() * tools.length)];

        const featuredTools = [toolToFeature];

        toolsGrid.innerHTML = featuredTools.map(tool => {
            const outOfStock = tool.stock <= 0;
            return `
                <div class="shop-item ${outOfStock ? 'out-of-stock' : ''}">
                    <h3>${tool.name}</h3>
                    <p>Multiplier: ${tool.multiplier}x</p>
                    <p class="price">Cost: ${tool.cost} points</p>
                    <p class="stock">Stock: ${tool.stock}/${tool.max_stock}</p>
                    <button class="btn-buy" 
                        data-tool-id="${tool.item_id}" 
                        data-cost="${tool.cost}" 
                        data-multiplier="${tool.multiplier}" 
                        ${outOfStock ? 'disabled' : ''}>
                        ${outOfStock ? 'Out of Stock' : 'Buy Tool'}
                    </button>
                </div>
            `;
        }).join('');

        document.querySelectorAll('.btn-buy:not([disabled])').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const toolId = e.target.dataset.toolId;
                const cost = parseInt(e.target.dataset.cost);
                const multiplier = parseFloat(e.target.dataset.multiplier);
                await buyTool(toolId, cost, multiplier);
            });
        });

    } catch (error) {
        console.error(error);
        toolsGrid.innerHTML = '<p>Error loading tools</p>';
    }
}



// ---------------- Buy Plant ----------------
async function buyPlant(plantId, cost) {
    const user = await loadUserData();
    if (!user || user.points < cost) {
        alert('Insufficient points!');
        return;
    }

    try {
        const response = await fetch(`${currentUrl}/plants/${plantId}/buy`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${getToken()}` },
            body: JSON.stringify({ user_id: parseInt(getUserId()) })
        });

        if (response.status === 401) return handleUnauthorized();
        if (!response.ok) {
            const error = await response.json();
            return handleFetchError(error, error.message || 'Failed to purchase plant');
        }

        alert('Plant purchased successfully! Check your inventory.');
        await loadUserData();
        await loadPlants();

    } catch (error) {
        handleFetchError(error, 'Error purchasing plant');
    }
}

// ---------------- Buy Tool ----------------
async function buyTool(toolId, cost, multiplier) {
    const user = await loadUserData();
    if (!user || user.points < cost) {
        alert('Insufficient points!');
        return;
    }

    if (!confirm(`This tool will multiply all your planted plants' value by ${multiplier}x. Continue?`)) return;

    try {
        const response = await fetch(`${currentUrl}/tools/${toolId}/buy`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${getToken()}` },
            body: JSON.stringify({ user_id: parseInt(getUserId()) })
        });

        if (response.status === 401) return handleUnauthorized();
        if (!response.ok) {
            const error = await response.json();
            return handleFetchError(error, error.message || 'Failed to purchase tool');
        }

        alert('Tool purchased! All planted plants have been boosted!');
        await loadUserData();
        await loadTools();

    } catch (error) {
        handleFetchError(error, 'Error purchasing tool');
    }
}

// ---------------- Shop Refresh Timer ----------------
async function startShopRefreshTimer() {
    async function updateTimer() {
        const now = new Date();
        const minutes = now.getMinutes();
        const seconds = now.getSeconds();

        const minutesMod = minutes % 5;
        const minutesUntilRefresh = (5 - minutesMod) % 5;
        const secondsUntilRefresh = 60 - seconds;

        const totalSeconds = (minutesUntilRefresh * 60 + secondsUntilRefresh) % 300;
        const displayMinutes = Math.floor(totalSeconds / 60);
        const displaySeconds = totalSeconds % 60;

        document.getElementById('timer-value').textContent =
            `${displayMinutes}:${displaySeconds.toString().padStart(2, '0')}`;

        if (totalSeconds === 0) {
            await loadPlants();  // refresh featured plants
            await loadTools();   // refresh tools if needed
        }
    }

    updateTimer();
    setInterval(updateTimer, 1000);
}

// ---------------- DOMContentLoaded ----------------
document.addEventListener('DOMContentLoaded', async () => {
    checkAuth();

    // Wait for user data first
    await loadUserData();

    // Then load shop
    await loadPlants();
    await loadTools();

    startShopRefreshTimer();

    document.getElementById('logout-btn').addEventListener('click', logout);
    document.getElementById('refresh-shop-btn').addEventListener('click', () => {
        loadPlants();
        loadTools();
    });
});